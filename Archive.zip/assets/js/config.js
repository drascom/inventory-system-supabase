export const config = {
    supabaseUrl: 'https://ykpqkrneoyynwxiyxvrh.supabase.co',
    supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlrcHFrcm5lb3l5bnd4aXl4dnJoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI1NzQ3OTIsImV4cCI6MjA1ODE1MDc5Mn0.bGo86AuzRDDg_-fweDWH09lDTPbfT6Na7MUeVwpQVRs'
};