export const config = {
    supabaseUrl: 'your-supabase-url',
    supabaseKey: 'your-supabase-anon-key'
};