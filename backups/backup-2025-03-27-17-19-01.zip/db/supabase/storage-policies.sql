-- Allow authenticated users to upload update files
CREATE POLICY "Allow authenticated users to upload updates" ON storage.objects
    FOR INSERT TO authenticated
    WITH CHECK (bucket_id = 'system-updates');

-- Allow authenticated users to download update files
CREATE POLICY "Allow authenticated users to download updates" ON storage.objects
    FOR SELECT TO authenticated
    USING (bucket_id = 'system-updates');

-- Allow authenticated users to delete old update files
CREATE POLICY "Allow authenticated users to delete updates" ON storage.objects
    FOR DELETE TO authenticated
    USING (bucket_id = 'system-updates');